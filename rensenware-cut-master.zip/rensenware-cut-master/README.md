# rensenWare
rensenWare(蓮船ウェアー, 련선웨어) is a ransomware. it does not demand to victims any money, but makes them play Touhou Project game and unlocks files when player reaches 200 million points of score.

Following extensions are target of rensenWare.
```
.jpg, .txt, .png, .pdf, .hwp, .psd, .cs, .c, .cpp, .vb, .bas, .frm, .mp3, .wav, .flac, .gif, .doc, .xls, .xlsx
.docx, .ppt, .pptx, .js, .avi, .mp4, .mkv, .zip, .rar, .alz, .egg, .7z, .raw
```
This repository does not contain entire of source code, but core part is archived to say what I wanted to do with this.

# Warning
The initial build of rensenWare (also initial release of source code) has no exception handlers, so it can be terminated unexpectedly and results permanent data loss.

SO PLEASE, DO NOT EXECUTE IT IF YOU ARE NOT SURE THAT YOUR DATA IS SAFE FROM RENSENWARE UNDER ANY CIRCUMSTANCES!

Also, DO NOT request me the entire(or encryption part) source code of rensenWare. I decided not to provide it to anyone.

# Need Forcer?
Repository : https://github.com/0x00000FF/rensenware_force

Release : https://github.com/0x00000FF/rensenware_force/releases

New version of Forcer (released in Dec. 18 KST) runs as decoy of rensenWare, so you don't have to buy or get Touhou game.

# If you want to get more informations..
Article of Bleeping Computer : https://www.bleepingcomputer.com/news/security/rensenware-will-only-decrypt-files-if-victim-scores-2-billion-in-th12-game/

or open Issues or PR.
